<?php

class Front_Model_EmployeesHeso extends Zend_Db_Table_Abstract {

    /**
     * Model Emloyees He So
     * @author Nguyen Manh Hung
     */
    protected $_name = TABLE_EMPLOYEESHESO;
    protected $_id = 'eh_id';
}