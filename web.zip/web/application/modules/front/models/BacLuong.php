<?php

class Front_Model_BacLuong extends Zend_Db_Table_Abstract {

    /**
     * Model Bac Luong
     * @author Nguyen Manh Hung
     */
    protected $_name = TABLE_BACLUONG;
    protected $_id = 'bl_id'; 
}