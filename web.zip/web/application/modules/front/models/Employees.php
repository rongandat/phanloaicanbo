<?php

class Front_Model_Employees extends Zend_Db_Table_Abstract {

    /**
     * Model Employees
     * @author Nguyen Manh Hung
     */
    protected $_name = TABLE_EMPLOYEES;
    protected $_id = 'employee_id';

}